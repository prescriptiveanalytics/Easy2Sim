﻿using System.Globalization;
using Easy2Sim.Connect;
using Easy2Sim.Environment;
using Easy2Sim.Solvers;
using Newtonsoft.Json;

namespace Easy2SimDocumentationTest.Domain;

public class LogInformationSink : SimulationBase
{
    [JsonProperty]
    public SimulationValue<string> Input;

    public LogInformationSink()
    {
        Input = new SimulationValue<string>("", nameof(Input), this, SimulationValueAttributes.Input);
    }

    public LogInformationSink(SimulationEnvironment environment, SolverBase solver) : base(environment, solver)
    {
        Input = new SimulationValue<string>("", nameof(Input), this, SimulationValueAttributes.Input);
    }
    public override void DynamicCalculation()
    {
        //Information received through the input is logged with the logging framework given in the simulation environment
        SimulationEnvironment?.LogEnvironmentInfo(Input.Value); // (1)
    }
}