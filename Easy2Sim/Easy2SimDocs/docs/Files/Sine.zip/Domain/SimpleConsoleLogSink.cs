﻿using Serilog.Core;
using Serilog.Events;

namespace Easy2SimDocumentationTest.Domain
{
    public class SimpleConsoleSink : ILogEventSink
    {
        private MainWindowModel mainWindowModel;

        public SimpleConsoleSink(MainWindowModel mainWindowModel)
        {
            this.mainWindowModel = mainWindowModel;
        }

        public void Emit(LogEvent logEvent)
        {
            // This sink connects the simulation with the visualization and adds generated data points to the model.
            if (double.TryParse(logEvent.RenderMessage(), out double value))
            {
                if (mainWindowModel.DataPoints1.Count > 200)
                {
                    mainWindowModel.DataPoints1.RemoveAt(0);
                }
                mainWindowModel.DataPoints1.Add(value);
            }
        }
    }
}
