﻿using System.Globalization;
using Easy2Sim.Connect;
using Easy2Sim.Environment;
using Easy2Sim.Solvers;
using Newtonsoft.Json;

namespace Easy2SimDocumentationTest.Domain;

public class Sine : SimulationBase // Each simulation component needs to implement SimulationBase
{
        
    [JsonProperty]
    public SimulationValue<string> Output;

    [JsonProperty] 
    public SimulationValue<double> Amplitude;
    [JsonProperty] 
    public SimulationValue<double> Frequency;
    [JsonProperty] 
    public SimulationValue<double> Offset;
    [JsonProperty] 
    public SimulationValue<int> NumberOfSamples;

    //An empty constructor is needed for the serialization framework 
    public Sine()
    {
        Amplitude = new SimulationValue<double>(1.0, nameof(Amplitude), this, SimulationValueAttributes.Parameter);
        Frequency = new SimulationValue<double>(1.0, nameof(Frequency), this, SimulationValueAttributes.Parameter);
        Offset = new SimulationValue<double>(0.0, nameof(Offset), this, SimulationValueAttributes.Parameter);
        //Output defines, that this Property can be connected to a Input of another component
        Output = new SimulationValue<string>("", nameof(Output), this, SimulationValueAttributes.Output); 
        NumberOfSamples = new SimulationValue<int>(100, nameof(NumberOfSamples), this, SimulationValueAttributes.Parameter);
    }

    //Use this constructor when you create components, it will register the components in the framework
    public Sine(SimulationEnvironment environment, SolverBase solverBase) : base(environment, solverBase) 
    {
        Amplitude = new SimulationValue<double>(1.0, nameof(Amplitude), this, SimulationValueAttributes.Parameter);
        Frequency = new SimulationValue<double>(1.0, nameof(Frequency), this, SimulationValueAttributes.Parameter);
        Offset = new SimulationValue<double>(0.0, nameof(Offset), this, SimulationValueAttributes.Parameter);
        //Output defines, that this Property can be connected to a Input of another component
        Output = new SimulationValue<string>("", nameof(Output), this, SimulationValueAttributes.Output); 
        NumberOfSamples = new SimulationValue<int>(100, nameof(NumberOfSamples), this, SimulationValueAttributes.Parameter);
    }

    // DynamicCalculation is called in every simulated time step in the Dynamic solver
    public override void DynamicCalculation() 
    {
        if (Solver == null) return;

        double timeInSeconds = (double)Solver.BaseModel.SimulationTime / (double)NumberOfSamples.Value;
        double angle = 2 * Math.PI * Frequency.Value * timeInSeconds + Offset.Value;
        double sineValue = Amplitude.Value * Math.Sin(angle);

        Output.SetValue(sineValue.ToString(CultureInfo.InvariantCulture));
    }
}