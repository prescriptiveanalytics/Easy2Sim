﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using LiveCharts;

namespace Easy2SimDocumentationTest
{
    public class MainWindowModel : INotifyPropertyChanged
    {
        private ChartValues<double> dataPoints1;

        // Property for all generated chart values
        public ChartValues<double> DataPoints1
        {
            get { return dataPoints1; }
            set
            {
                dataPoints1 = value;
                OnPropertyChanged();
            }
        }

        public MainWindowModel()
        {
            DataPoints1 = new ChartValues<double> { };
        }
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public event PropertyChangedEventHandler? PropertyChanged;
    }
}
