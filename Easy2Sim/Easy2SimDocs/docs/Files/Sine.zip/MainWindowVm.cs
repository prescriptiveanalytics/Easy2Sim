﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Easy2Sim.Environment;
using Easy2Sim.Solvers.Dynamic;
using Easy2SimDocumentationTest.Domain;
using Serilog;
using Serilog.Core;

namespace Easy2SimDocumentationTest
{
    public class MainWindowVm : INotifyPropertyChanged
    {
        public MainWindowModel MainWindowModel { get; set; }

        /// <summary>
        /// Used for xaml code completion
        /// </summary>
        public MainWindowVm() { }

        public MainWindowVm(object v)
        {
            // Create a model that holds the current data for visualization
            MainWindowModel = new MainWindowModel();

            //The logger is used pass generated information to the MainWindowModel
            Logger l1 = new LoggerConfiguration()
                .WriteTo.Sink(new SimpleConsoleSink(MainWindowModel)) // Use the custom console sink
                .CreateLogger();


            Task.Run(() => // Start a background task that runs the simulation so that the gui is not blocked
            {
                // Initialize one environment, solver, and set the delay between the generated values to 20 ms
                SimulationEnvironment simulationEnvironment = new SimulationEnvironment();
                DynamicSolver solver = new DynamicSolver(simulationEnvironment);
                solver.BaseModel.Delay = 20;
                simulationEnvironment.Model.Easy2SimLogging.FrameworkDebuggingLogger = l1;

                // Instantiate one Sine component, one sink and connect both components
                Sine sine = new Sine(simulationEnvironment, solver);
                LogInformationSink logInformationSink = new LogInformationSink(simulationEnvironment, solver);
                simulationEnvironment.AddConnection<string>(sine.Output, logInformationSink.Input);

                // Initialize and start the simulation
                solver.Initialize();
                solver.CalculateTo(500);
            });
        }
        public event PropertyChangedEventHandler? PropertyChanged;
    }
}
